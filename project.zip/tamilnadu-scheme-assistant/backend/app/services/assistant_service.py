import sys
from pathlib import Path
from app.core.config import settings, BASE_DIR

from app.models.query import QueryRequest, QueryResponse, EligibilityCheckResponse
from app.models.scheme import SchemeResponse
from app.models.session import UserProfile
from app.services.scheme_service import scheme_service
from app.services.nlu_service import nlu_service
from app.eligibility.rule_evaluator import EligibilityEngine
from app.ai.llm.raw_model import llm_service

class AssistantService:
    async def process_query(self, request: QueryRequest) -> QueryResponse:
        language = request.language or nlu_service.detect_language(request.query)
        intent = nlu_service.classify_intent(request.query)
        entities = nlu_service.extract_entities(request.query)

        # Build user profile from entities or request.profile_updates
        profile_data = request.profile_updates or {}
        profile_data.update(entities)
        profile = UserProfile(**profile_data)

        # Search schemes based on query and enriched profile
        filters = {}
        raw_schemes = await scheme_service.search_schemes(request.query, filters, profile=profile)
        
        schemes = []
        eligibility_summaries = []
        official_sources = []
        
        status_priority = {
            "ELIGIBLE": 0,
            "POTENTIALLY_ELIGIBLE": 1,
            "INSUFFICIENT_INFORMATION": 2,
            "NOT_APPEARING_ELIGIBLE": 3
        }

        query_lower = request.query.lower()
        evaluated_pairs = []
        for idx, scheme_dict in enumerate(raw_schemes):
            eval_result = EligibilityEngine.evaluate(profile, scheme_dict)
            
            scheme_response = SchemeResponse(**scheme_dict)
            scheme_response.eligibility_status = eval_result.status
            scheme_response.matched_criteria = eval_result.matched_criteria
            scheme_response.unmet_criteria = eval_result.unmet_criteria
            scheme_response.missing_criteria = eval_result.missing_criteria
            
            elig_summary = EligibilityCheckResponse(
                scheme_id=scheme_response.scheme_id,
                status=eval_result.status,
                matched_criteria=eval_result.matched_criteria,
                unmet_criteria=eval_result.unmet_criteria,
                missing_criteria=eval_result.missing_criteria,
                reasoning_tamil=eval_result.reasoning_tamil,
                reasoning_english=eval_result.reasoning_english,
                confidence=eval_result.confidence
            )
            
            # Domain relevance bonus for specific loan, business, job, pension, education queries
            domain_bonus = 0
            name_en = scheme_response.scheme_name_english.lower()
            name_ta = scheme_response.scheme_name_tamil.lower()
            cat = (scheme_response.category or "").lower()
            
            rel_keywords = [
                ("loan", ["loan", "கடன்", "subsidy", "மானியம்"]),
                ("business", ["business", "தொழில்", "entrepreneur", "enterprise"]),
                ("job", ["job", "வேலை", "employment", "unemployed", "முதல்வன்"]),
                ("pension", ["pension", "ஓய்வூதியம்", "முதியோர்"]),
                ("college", ["college", "கல்லூரி", "student", "மாணவர்", "படிப்பு", "பட்டதாரி"]),
            ]
            for kw, related_terms in rel_keywords:
                if any(k in query_lower for k in related_terms):
                    if any(t in name_en or t in name_ta or t in cat for t in related_terms):
                        domain_bonus += 10
            
            status_weight = status_priority.get(eval_result.status, 2)
            # Final ranking score: lower is better. Heavily reward domain match and eligibility.
            final_score = (status_weight * 10) - domain_bonus + (idx * 0.1)
            evaluated_pairs.append((final_score, scheme_response, elig_summary))

        # Sort so domain-relevant Eligible and Potentially Eligible schemes always appear at the top
        evaluated_pairs.sort(key=lambda x: x[0])

        for _, scheme_resp, elig_sum in evaluated_pairs[:6]:
            schemes.append(scheme_resp)
            eligibility_summaries.append(elig_sum)
            for url in scheme_resp.official_urls:
                official_sources.append({"name": scheme_resp.scheme_name_english, "url": url})

        is_tamil = language in ["ta", "tamil", "ta-en"]
        lang_name = "Tamil" if is_tamil else "English"

        top_scheme_name = ""
        top_scheme_benefit = ""
        if schemes:
            first = schemes[0]
            top_scheme_name = first.scheme_name_tamil if is_tamil else first.scheme_name_english
            if first.benefits:
                first_benefit_val = next(iter(first.benefits.values()))
                top_scheme_benefit = str(first_benefit_val)

        # Generate response text dynamically using LLM
        system_prompt = (
            "You are 'Arasu Nanban' (Government Companion & Helper Guide), a warm, caring, and deeply empathetic voice assistant for Tamil Nadu Government Schemes. "
            "You talk like a knowledgeable, kind human friend or elder sibling sitting next to the user. "
            "Speak conversationally and naturally. Do NOT sound like a robotic IVR or bureaucratic form. "
            "Never say robotic phrases like 'Status: POTENTIALLY_ELIGIBLE' or 'Matched criteria'. "
            "Instead, comfort the user, explain why the scheme helps their real life, mention the key benefit, and encourage them. "
            f"Speak naturally in {lang_name}. Ground all facts strictly in the verified scheme data provided."
        )
        
        context = f"User Query: {request.query}\nIntent: {intent}\nLanguage: {lang_name}\n\n"
        if schemes:
            context += "Relevant Schemes:\n"
            for scheme, eval_res in zip(schemes, eligibility_summaries):
                context += f"- {scheme.scheme_name_english} ({scheme.scheme_name_tamil})\n"
                context += f"  Status: {eval_res.status}\n"
                if eval_res.reasoning_tamil and is_tamil:
                    context += f"  Reasoning (Tamil): {eval_res.reasoning_tamil}\n"
                elif eval_res.reasoning_english:
                    context += f"  Reasoning (English): {eval_res.reasoning_english}\n"
                if eval_res.missing_criteria:
                    context += f"  Missing Info: {', '.join(eval_res.missing_criteria)}\n"
        else:
            context += "No schemes matched the query.\n"
            
        user_prompt = f"{context}\n\nPlease provide a clear, warm, conversational explanation suitable for natural voice readout."
        
        response_text = llm_service.generate(
            system_prompt,
            user_prompt,
            language=lang_name,
            num_schemes=len(schemes),
            top_scheme_name=top_scheme_name,
            top_scheme_benefit=top_scheme_benefit
        )
        
        # Populate appropriate language response fields
        if is_tamil:
            response_text_tamil = response_text
            response_text_english = ""
        else:
            response_text_tamil = ""
            response_text_english = response_text
        
        # Missing prompts calculation
        missing_prompts = []
        if intent == "check_eligibility" and eligibility_summaries:
            all_missing = set()
            for e in eligibility_summaries:
                if e.status in ["POTENTIALLY_ELIGIBLE", "INSUFFICIENT_INFORMATION"]:
                    for m in e.missing_criteria:
                        all_missing.add(m)
            missing_prompts = list(all_missing)

        return QueryResponse(
            response_text_tamil=response_text_tamil,
            response_text_english=response_text_english,
            detected_language=language,
            detected_intent=intent,
            extracted_entities=entities,
            schemes=schemes,
            eligibility_summaries=eligibility_summaries,
            missing_info_prompts=missing_prompts,
            official_sources=official_sources
        )

assistant_service = AssistantService()
