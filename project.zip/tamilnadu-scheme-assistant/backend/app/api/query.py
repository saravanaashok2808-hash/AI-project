from fastapi import APIRouter
from app.models.query import QueryRequest, QueryResponse
from app.services.assistant_service import assistant_service

router = APIRouter()

@router.post("/", response_model=QueryResponse)
async def process_query(request: QueryRequest):
    return await assistant_service.process_query(request)
