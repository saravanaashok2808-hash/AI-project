import { useState, useEffect } from 'react';
import { LandingPage } from './components/LandingPage';
import { AuthPage } from './components/AuthPage';
import { ProfileOnboarding } from './components/ProfileOnboarding';
import { AssistantPage } from './components/AssistantPage';
import type { UserProfile } from './types';

type AppState = 'landing' | 'auth' | 'onboarding' | 'assistant';

function App() {
  const [appState, setAppState] = useState<AppState>('landing');
  const [language, setLanguage] = useState<'ta' | 'en'>('ta');
  const [currentCitizen, setCurrentCitizen] = useState<UserProfile>({});
  const [onboardingInitialProfile, setOnboardingInitialProfile] = useState<UserProfile>({});

  // Check for saved citizen session on startup
  useEffect(() => {
    try {
      const saved = localStorage.getItem('tn_current_citizen');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.name) {
          setCurrentCitizen(parsed);
        }
      }
    } catch {
      // Ignore parse errors
    }
  }, []);

  const handleLandingSignIn = (lang: 'ta' | 'en') => {
    setLanguage(lang);
    setAppState('auth');
  };

  const handleLandingSignUp = (lang: 'ta' | 'en') => {
    setLanguage(lang);
    setOnboardingInitialProfile({});
    setAppState('onboarding');
  };

  const handleLandingQuickStart = (lang: 'ta' | 'en') => {
    setLanguage(lang);
    setOnboardingInitialProfile(currentCitizen.name ? currentCitizen : {});
    setAppState('onboarding');
  };

  const handleAuthLogin = (profile: UserProfile) => {
    setCurrentCitizen(profile);
    localStorage.setItem('tn_current_citizen', JSON.stringify(profile));
    setAppState('assistant');
  };

  const handleAuthSignUp = (initialProfile: UserProfile) => {
    setOnboardingInitialProfile(initialProfile);
    setAppState('onboarding');
  };

  const handleOnboardingComplete = (profile: UserProfile) => {
    setCurrentCitizen(profile);
    localStorage.setItem('tn_current_citizen', JSON.stringify(profile));

    // Also update saved citizens list
    try {
      const existingStr = localStorage.getItem('tn_saved_citizens');
      const existing: UserProfile[] = existingStr ? JSON.parse(existingStr) : [];
      const filtered = existing.filter(c => c.name?.toLowerCase() !== profile.name?.toLowerCase());
      filtered.unshift(profile);
      localStorage.setItem('tn_saved_citizens', JSON.stringify(filtered.slice(0, 10)));
    } catch {
      // Ignore error
    }

    setAppState('assistant');
  };

  const handleEditProfile = () => {
    setOnboardingInitialProfile(currentCitizen);
    setAppState('onboarding');
  };

  const handleLogout = () => {
    localStorage.removeItem('tn_current_citizen');
    setCurrentCitizen({});
    setAppState('landing');
  };

  const handleHome = () => {
    setAppState('landing');
  };

  return (
    <>
      {appState === 'landing' && (
        <LandingPage 
          onSignIn={handleLandingSignIn}
          onSignUp={handleLandingSignUp}
          onQuickStart={handleLandingQuickStart}
        />
      )}

      {appState === 'auth' && (
        <AuthPage 
          language={language}
          onLogin={handleAuthLogin}
          onSignUp={handleAuthSignUp}
          onGuest={() => setAppState('onboarding')}
        />
      )}

      {appState === 'onboarding' && (
        <ProfileOnboarding 
          language={language}
          initialProfile={onboardingInitialProfile}
          onComplete={handleOnboardingComplete}
          onSkip={() => setAppState('assistant')}
        />
      )}

      {appState === 'assistant' && (
        <AssistantPage 
          language={language}
          initialProfile={currentCitizen}
          onHome={handleHome}
          onEditProfile={handleEditProfile}
          onLogout={handleLogout}
        />
      )}
    </>
  );
}

export default App;
