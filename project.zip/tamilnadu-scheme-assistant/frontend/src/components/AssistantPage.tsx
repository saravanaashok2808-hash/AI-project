import React, { useState, useRef, useEffect } from 'react';
import { Send, Menu, Loader2, Home, Volume2, VolumeX, User, LogOut, Edit3 } from 'lucide-react';
import { ApiClient } from '../api/client';
import type { QueryRequest, UserProfile, Scheme } from '../types';
import { SchemeCard } from './SchemeCard';
import { AudioRecorder } from './AudioRecorder';
import { ProfileSidebar } from './ProfileSidebar';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  schemes?: Scheme[];
  eligibilityData?: any;
}

interface AssistantPageProps {
  language: 'ta' | 'en';
  initialProfile: UserProfile;
  onHome: () => void;
  onEditProfile: () => void;
  onLogout: () => void;
}

export const AssistantPage: React.FC<AssistantPageProps> = ({
  language: initialLang,
  initialProfile,
  onHome,
  onEditProfile,
  onLogout
}) => {
  const [language, setLanguage] = useState<'ta' | 'en'>(initialLang);
  const [userProfile, setUserProfile] = useState<UserProfile>(initialProfile);
  const [voiceGender, setVoiceGender] = useState<'female' | 'male'>(initialProfile.voice_gender || 'female');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const citizenName = userProfile.name || (initialLang === 'ta' ? 'அன்பரே' : 'Citizen');

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'assistant',
      text: initialLang === 'ta' 
        ? `வணக்கம் ${citizenName}! நான் உங்கள் 'அரசு நண்பன்' (AI நலத்திட்ட வழிகாட்டி). உங்கள் சுயவிவரத்தின்படி (வயது: ${userProfile.age || 24}, கல்வி: ${userProfile.education_level || 'பட்டதாரி'}, மாவட்டம்: ${userProfile.district || 'தமிழ்நாடு'}) உங்களுக்குப் பொருத்தமான அரசு நலத்திட்டங்களை ஆய்வு செய்து கீழே கொடுத்துள்ளேன். உங்களுக்கு என்ன உதவி தேவை என்பதை கேட்கலாம்!`
        : `Welcome ${citizenName}! I am 'Arasu Nanban', your Government Scheme Guide. Based on your profile (Age: ${userProfile.age || 24}, Education: ${userProfile.education_level || 'Graduate'}, District: ${userProfile.district || 'Tamil Nadu'}), I have evaluated verified welfare schemes for you below. Feel free to speak or ask anything!`,
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId] = useState(() => Math.random().toString(36).substring(7));
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(true);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isTa = language === 'ta';

  // Fallback to browser synthesis if neural API fails
  const fallbackSpeech = (text: string, lang: 'ta' | 'en') => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang === 'ta' ? 'ta-IN' : 'en-IN';
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    }
  };

  // High-Quality Studio Neural Human TTS
  const speakText = async (text: string, lang?: 'ta' | 'en') => {
    try {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }

      setIsPlayingAudio(true);
      const targetLang = (lang || language) === 'ta' ? 'ta' : 'en';
      const audioUrl = await ApiClient.synthesizeSpeech(text, targetLang, voiceGender);
      const audio = new Audio(audioUrl);
      audioRef.current = audio;
      audio.onended = () => setIsPlayingAudio(false);
      audio.onerror = () => {
        setIsPlayingAudio(false);
        fallbackSpeech(text, targetLang);
      };
      await audio.play();
    } catch (err) {
      console.warn('Backend neural TTS failed, falling back to speech synthesis:', err);
      setIsPlayingAudio(false);
      fallbackSpeech(text, (lang || language) === 'ta' ? 'ta' : 'en');
    }
  };

  // Initial load: Fetch customized schemes automatically based on citizen profile
  useEffect(() => {
    const fetchInitialSchemes = async () => {
      setIsLoading(true);
      try {
        const queryText = isTa 
          ? `என் வயது ${userProfile.age || 24}, ${userProfile.education_level || 'பட்டதாரி'}, ${userProfile.employment_status || 'வேலை தேடுபவர்'}. எனக்கு ஏற்ற திட்டங்கள் எவை?`
          : `Schemes suitable for my profile: age ${userProfile.age || 24}, ${userProfile.education_level || 'graduate'}, ${userProfile.employment_status || 'unemployed'}`;

        const req: QueryRequest = {
          query: queryText,
          language: isTa ? 'ta' : 'en',
          session_id: sessionId,
          user_profile: userProfile
        };

        const response = await ApiClient.query(req);

        setMessages(prev => [
          prev[0],
          {
            id: 'init_schemes',
            sender: 'assistant',
            text: response.answer_text,
            schemes: response.schemes,
            eligibilityData: response.eligibility_checks
          }
        ]);

        if (autoSpeak) {
          speakText(response.answer_text, response.language as 'ta' | 'en');
        }
      } catch (e) {
        console.error('Initial scheme fetch failed:', e);
      } finally {
        setIsLoading(false);
      }
    };

    fetchInitialSchemes();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = { id: Date.now().toString(), sender: 'user', text };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const req: QueryRequest = {
        query: text,
        language: 'ta-en',
        session_id: sessionId,
        user_profile: userProfile
      };

      const response = await ApiClient.query(req);

      if (response.extracted_profile) {
        setUserProfile(response.extracted_profile);
      }
      
      if (response.language === 'ta' || response.language === 'en') {
        setLanguage(response.language as 'ta' | 'en');
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: response.answer_text,
        schemes: response.schemes,
        eligibilityData: response.eligibility_checks
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Speak response if autoSpeak is enabled
      if (autoSpeak) {
        speakText(response.answer_text, response.language as 'ta' | 'en');
      }

    } catch (error) {
      console.error(error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        text: isTa ? 'மன்னிக்கவும், பிழை ஏற்பட்டுள்ளது. மீண்டும் முயற்சிக்கவும்.' : 'Sorry, an error occurred. Please try again.',
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearSession = () => {
    setUserProfile({});
    setMessages([
      {
        id: Date.now().toString(),
        sender: 'assistant',
        text: isTa ? 'உங்கள் தரவுகள் அழிக்கப்பட்டன. புதிதாக தொடங்குவோம்.' : 'Your data has been cleared. Let\'s start fresh.',
      }
    ]);
    setSidebarOpen(false);
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-[#1B5E20] text-white p-3 sm:p-4 shadow-md flex justify-between items-center z-10">
        <div className="flex items-center gap-2.5">
          <button onClick={onHome} className="p-2 hover:bg-white/20 rounded-full transition-colors" title={isTa ? 'முகப்பு' : 'Home'}>
            <Home size={19} />
          </button>
          <div className="w-8 h-8 bg-[#FFD700] rounded-full flex items-center justify-center shrink-0 shadow">
            <img src="/vite.svg" alt="Logo" className="w-5 h-5" />
          </div>
          <div className="hidden md:block">
            <h1 className="font-bold text-base leading-tight">
              {isTa ? 'தமிழ்நாடு அரசுத் திட்ட வழிகாட்டி' : 'TN Scheme Assistant'}
            </h1>
            <div className="flex items-center gap-1.5 text-[11px] text-[#FFD700]">
              <User size={11} />
              <span>{userProfile.name || 'குடிமக்கள்'}, {userProfile.age || 24}y ({userProfile.district || 'தமிழ்நாடு'})</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Human Voice Persona Toggle */}
          <button
            onClick={() => setVoiceGender(voiceGender === 'female' ? 'male' : 'female')}
            className="text-xs bg-white/15 hover:bg-white/25 px-2.5 py-1.5 rounded-full transition-colors flex items-center gap-1 border border-white/20"
            title={isTa ? 'மனிதக் குரல் மாற்றவும்' : 'Switch Human Voice'}
          >
            <span>{voiceGender === 'female' ? '👩 பல்லவி' : '👨 வள்ளுவர்'}</span>
          </button>

          {/* Voice Narration ON/OFF with live playing indicator */}
          <button 
            onClick={() => {
              if (audioRef.current) {
                audioRef.current.pause();
              }
              if (autoSpeak && 'speechSynthesis' in window) {
                window.speechSynthesis.cancel();
              }
              setAutoSpeak(!autoSpeak);
            }}
            className={`px-2.5 py-1.5 rounded-full transition-colors flex items-center gap-1.5 text-xs font-medium border ${
              autoSpeak 
                ? 'bg-white/20 text-[#FFD700] border-[#FFD700]/40' 
                : 'bg-black/20 text-white/70 border-white/10'
            }`}
            title={autoSpeak ? (isTa ? 'குரல் வாசிப்பு ஆன்' : 'Voice Narration ON') : (isTa ? 'குரல் வாசிப்பு ஆஃப்' : 'Voice Narration OFF')}
          >
            {isPlayingAudio ? (
              <span className="flex items-center gap-0.5">
                <span className="w-1 h-3 bg-[#FFD700] animate-pulse" />
                <span className="w-1 h-4 bg-[#FFD700] animate-pulse delay-75" />
                <span className="w-1 h-2 bg-[#FFD700] animate-pulse delay-150" />
              </span>
            ) : (
              autoSpeak ? <Volume2 size={16} /> : <VolumeX size={16} />
            )}
            <span className="hidden lg:inline">{autoSpeak ? (isTa ? 'குரல் ஆன்' : 'Voice ON') : (isTa ? 'குரல் ஆஃப்' : 'Voice OFF')}</span>
          </button>

          {/* Language Toggle */}
          <button
            onClick={() => setLanguage(isTa ? 'en' : 'ta')}
            className="text-xs bg-white/20 hover:bg-white/30 px-2.5 py-1.5 rounded-full transition-colors font-medium cursor-pointer border border-white/30 hidden sm:inline-flex"
            title={isTa ? 'Switch to English' : 'தமிழுக்கு மாறவும்'}
          >
            {isTa ? 'தமிழ் ⇄ English' : 'English ⇄ தமிழ்'}
          </button>

          {/* Edit Profile Button */}
          <button
            onClick={onEditProfile}
            className="p-2 hover:bg-white/20 rounded-full transition-colors text-white/90 hover:text-white"
            title={isTa ? 'சுயவிவரம் மாற்ற' : 'Edit Profile'}
          >
            <Edit3 size={18} />
          </button>

          {/* Sidebar drawer */}
          <button 
            onClick={() => setSidebarOpen(true)}
            className="p-2 hover:bg-white/20 rounded-full transition-colors relative"
            aria-label="Profile Details"
            title={isTa ? 'முழு விவரங்கள்' : 'Profile Details'}
          >
            <Menu size={20} />
            {Object.keys(userProfile).length > 0 && (
              <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-[#FFD700] rounded-full border border-[#1B5E20]" />
            )}
          </button>

          {/* Logout button */}
          <button
            onClick={onLogout}
            className="p-2 hover:bg-red-500/30 rounded-full transition-colors text-white/80 hover:text-red-200"
            title={isTa ? 'வெளியேறு' : 'Sign Out'}
          >
            <LogOut size={18} />
          </button>
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 pb-24">
        <div className="max-w-3xl mx-auto space-y-6">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 shadow-sm ${
                msg.sender === 'user' 
                  ? 'bg-[#1B5E20] text-white rounded-tr-none' 
                  : 'bg-white border border-gray-200 text-gray-800 rounded-tl-none'
              }`}>
                {msg.sender === 'assistant' && (
                  <div className="flex items-center justify-between gap-2 mb-2 pb-1.5 border-b border-gray-100">
                    <span className="text-[11px] font-semibold text-[#1B5E20] uppercase tracking-wider">
                      {isTa ? 'தமிழ்நாடு அரசு வழிகாட்டி' : 'TN Assistant'}
                    </span>
                    <button
                      onClick={() => speakText(msg.text, isTa ? 'ta' : 'en')}
                      className="p-1 rounded hover:bg-gray-100 text-gray-500 hover:text-[#1B5E20] transition-colors flex items-center gap-1 text-xs"
                      title={isTa ? 'குரலில் கேட்கவும்' : 'Listen to voice'}
                    >
                      <Volume2 size={15} />
                      <span className="text-[11px]">{isTa ? 'கேட்க' : 'Listen'}</span>
                    </button>
                  </div>
                )}
                <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                
                {msg.schemes && msg.schemes.length > 0 && (
                  <div className="mt-4 space-y-4">
                    {msg.schemes.map(scheme => {
                      const elig = msg.eligibilityData?.find((e: any) => e.scheme_id === scheme.id);
                      return (
                        <SchemeCard 
                          key={scheme.id} 
                          scheme={scheme} 
                          eligibilityStatus={elig?.status}
                          eligibilityReason={isTa ? elig?.reason_ta : elig?.reason_en}
                          language={language} 
                        />
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white border border-gray-200 rounded-2xl rounded-tl-none p-4 shadow-sm flex items-center gap-2 text-gray-500">
                <Loader2 size={16} className="animate-spin" />
                <span className="text-sm">{isTa ? 'பதிலளிக்கிறேன்...' : 'Processing...'}</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <div className="fixed bottom-0 inset-x-0 bg-white border-t border-gray-200 p-3 sm:p-4 z-10">
        <div className="max-w-3xl mx-auto flex items-end gap-2">
          <div className="flex-1 bg-gray-50 border border-gray-300 rounded-3xl flex items-center overflow-hidden focus-within:ring-2 focus-within:ring-[#1B5E20]/50 transition-all">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend(input);
                }
              }}
              placeholder={isTa ? 'உங்கள் கேள்வியைத் தட்டச்சு செய்யவும்...' : 'Type your query here...'}
              className="flex-1 max-h-32 min-h-[44px] bg-transparent border-none focus:ring-0 resize-none py-3 px-4 outline-none text-sm sm:text-base"
              rows={1}
            />
          </div>
          
          <div className="flex shrink-0 gap-2 h-11">
            <AudioRecorder 
              onTranscription={handleSend} 
              language={language === 'ta' ? 'ta-IN' : 'en-IN'} 
            />
            <button
              onClick={() => handleSend(input)}
              disabled={!input.trim() || isLoading}
              className="p-3 bg-[#1B5E20] text-white rounded-full hover:bg-[#144718] disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
              aria-label="Send message"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>

      <ProfileSidebar 
        profile={userProfile} 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)} 
        onClearSession={handleClearSession}
        language={language}
      />
    </div>
  );
};
