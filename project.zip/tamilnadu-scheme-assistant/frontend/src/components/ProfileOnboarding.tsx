import React, { useState } from 'react';
import type { UserProfile } from '../types';
import { User, Sparkles, ArrowRight, ShieldCheck, Volume2 } from 'lucide-react';

interface ProfileOnboardingProps {
  initialProfile?: UserProfile;
  language: 'ta' | 'en';
  onComplete: (profile: UserProfile) => void;
  onSkip?: () => void;
}

export const TN_DISTRICTS = [
  'Ariyalur', 'Chengalpattu', 'Chennai', 'Coimbatore', 'Cuddalore', 'Dharmapuri',
  'Dindigul', 'Erode', 'Kallakurichi', 'Kancheepuram', 'Kanyakumari', 'Karur',
  'Krishnagiri', 'Madurai', 'Mayiladuthurai', 'Nagapattinam', 'Namakkal', 'Nilgiris',
  'Perambalur', 'Pudukkottai', 'Ramanathapuram', 'Ranipet', 'Salem', 'Sivaganga',
  'Tenkasi', 'Thanjavur', 'Theni', 'Thoothukudi', 'Tiruchirappalli', 'Tirunelveli',
  'Tirupathur', 'Tiruppur', 'Tiruvallur', 'Tiruvannamalai', 'Tiruvarur', 'Vellore',
  'Viluppuram', 'Virudhunagar'
];

export const ProfileOnboarding: React.FC<ProfileOnboardingProps> = ({
  initialProfile = {},
  language,
  onComplete,
  onSkip
}) => {
  const isTa = language === 'ta';

  const [formData, setFormData] = useState<UserProfile>({
    name: initialProfile.name || '',
    phone: initialProfile.phone || '',
    age: initialProfile.age || 24,
    gender: initialProfile.gender || 'Female',
    district: initialProfile.district || 'Chennai',
    education_level: initialProfile.education_level || 'Graduate',
    employment_status: initialProfile.employment_status || 'Unemployed',
    occupation: initialProfile.occupation || 'Farmer',
    income: initialProfile.income || 60000,
    caste_category: initialProfile.caste_category || 'BC',
    marital_status: initialProfile.marital_status || 'Single',
    disability: initialProfile.disability || false,
    voice_gender: initialProfile.voice_gender || 'female'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete(formData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D3B13] via-[#1B5E20] to-[#0A290E] p-4 sm:p-6 flex items-center justify-center">
      <div className="max-w-2xl w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-emerald-100 my-8">
        
        {/* Header Banner */}
        <div className="bg-[#1B5E20] text-white p-6 sm:p-8 relative">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 bg-[#FFD700]/20 text-[#FFD700] px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase">
              <Sparkles size={14} />
              {isTa ? 'தனிப்பயனாக்கப்பட்ட அரசு உதவி' : 'Personalized Scheme Discovery'}
            </div>
            {onSkip && (
              <button 
                type="button"
                onClick={onSkip} 
                className="text-xs text-white/80 hover:text-white underline"
              >
                {isTa ? 'பிறகு நிரப்புகிறேன்' : 'Skip for now'}
              </button>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold">
            {isTa ? 'உங்கள் சுயவிவரம் (Citizen Profile)' : 'Complete Your Citizen Profile'}
          </h1>
          <p className="text-white/80 text-sm mt-1">
            {isTa 
              ? 'உங்கள் வயது, கல்வி மற்றும் வேலை விவரங்களைக் குறிப்பிட்டால், உங்களுக்குப் பொருந்தும் 59+ அரசு நலத்திட்டங்களை துல்லியமாக கண்டறிய முடியும்.' 
              : 'Tell us a few details about yourself so we can match you with verified Tamil Nadu Government schemes.'}
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">

          {/* Section 1: Basic Information */}
          <div>
            <h2 className="text-sm font-bold text-[#1B5E20] uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <User size={16} />
              {isTa ? '1. அடிப்படை விவரங்கள்' : '1. Basic Information'}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'உங்கள் பெயர்' : 'Full Name'} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name || ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder={isTa ? 'எ.கா: கார்த்திக் / பிரியா' : 'e.g., Karthik / Priya'}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'வயது' : 'Age (Years)'} *
                </label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  required
                  value={formData.age || ''}
                  onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) || 0 })}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'பாலினம்' : 'Gender'}
                </label>
                <select
                  value={formData.gender || 'Female'}
                  onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                >
                  <option value="Female">{isTa ? 'பெண் (Female)' : 'Female'}</option>
                  <option value="Male">{isTa ? 'ஆண் (Male)' : 'Male'}</option>
                  <option value="Transgender">{isTa ? 'திருநங்கை (Transgender)' : 'Transgender'}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'மாவட்டம்' : 'District'}
                </label>
                <select
                  value={formData.district || 'Chennai'}
                  onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                >
                  {TN_DISTRICTS.map((dist) => (
                    <option key={dist} value={dist}>{dist}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Section 2: Education & Employment */}
          <div>
            <h2 className="text-sm font-bold text-[#1B5E20] uppercase tracking-wider mb-3">
              {isTa ? '2. கல்வி & வேலைவாய்ப்பு நிலை' : '2. Education & Employment'}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'கல்வித் தகுதி' : 'Education Level'}
                </label>
                <select
                  value={formData.education_level || 'Graduate'}
                  onChange={(e) => setFormData({ ...formData, education_level: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                >
                  <option value="School">{isTa ? 'பள்ளி படிப்பு (1-10th)' : 'Schooling'}</option>
                  <option value="12th">{isTa ? '12ஆம் வகுப்பு (+2)' : 'Higher Secondary (12th)'}</option>
                  <option value="Diploma">{isTa ? 'டிப்ளமோ / ITI' : 'Diploma / ITI'}</option>
                  <option value="Graduate">{isTa ? 'பட்டதாரி (Degree / Engineering)' : 'Graduate (Degree)'}</option>
                  <option value="PostGraduate">{isTa ? 'முதுகலை (PG / PhD)' : 'Post Graduate'}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'வேலை நிலை' : 'Employment Status'}
                </label>
                <select
                  value={formData.employment_status || 'Unemployed'}
                  onChange={(e) => setFormData({ ...formData, employment_status: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                >
                  <option value="Unemployed">{isTa ? 'வேலை தேடுபவர் (Unemployed / Looking for Job)' : 'Unemployed / Job Seeker'}</option>
                  <option value="Student">{isTa ? 'மாணவர் (Student)' : 'Student'}</option>
                  <option value="Employed">{isTa ? 'பணியில் உள்ளார் (Employed / Salaried)' : 'Employed / Salaried'}</option>
                  <option value="SelfEmployed">{isTa ? 'சுயதொழில் / தொழில்முனைவோர்' : 'Self-Employed / Business'}</option>
                  <option value="DailyWage">{isTa ? 'கூலித் தொழிலாளி (Daily Wage)' : 'Daily Wage Worker'}</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'தொழில் / பணிப் பிரிவு' : 'Occupation / Work Sector'}
                </label>
                <select
                  value={formData.occupation || 'Farmer'}
                  onChange={(e) => setFormData({ ...formData, occupation: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                >
                  <option value="Farmer">{isTa ? 'விவசாயி / உழவர் (Farmer)' : 'Farmer / Agriculture'}</option>
                  <option value="Weaver">{isTa ? 'கைத்தறி நெசவாளர் (Weaver)' : 'Handloom Weaver'}</option>
                  <option value="Fisherman">{isTa ? 'மீனவர் (Fisherman)' : 'Fisherman'}</option>
                  <option value="Construction">{isTa ? 'கட்டுமானத் தொழிலாளி (Construction Worker)' : 'Construction Worker'}</option>
                  <option value="Driver">{isTa ? 'ஆட்டோ / கார் ஓட்டுநர் (Driver)' : 'Auto / Commercial Driver'}</option>
                  <option value="Tailor">{isTa ? 'தையல் கலைஞர் (Tailor)' : 'Tailor / Garments'}</option>
                  <option value="Entrepreneur">{isTa ? 'சிறு தொழில்முனைவோர் (Small Business / MSME)' : 'Small Business / MSME'}</option>
                  <option value="Student">{isTa ? 'மாணவர் (Student)' : 'Student'}</option>
                  <option value="Other">{isTa ? 'இதர பிரிவுகள் (General / Other)' : 'General / Other'}</option>
                </select>
              </div>
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Section 3: Social & Income Details */}
          <div>
            <h2 className="text-sm font-bold text-[#1B5E20] uppercase tracking-wider mb-3">
              {isTa ? '3. சமூக & வருமான விவரங்கள்' : '3. Social & Income Details'}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'குடும்ப ஆண்டு வருமானம்' : 'Annual Family Income'}
                </label>
                <select
                  value={formData.income || 60000}
                  onChange={(e) => setFormData({ ...formData, income: parseInt(e.target.value) || 0 })}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                >
                  <option value={50000}>{isTa ? '₹72,000-க்கு கீழ் (BPL / வறுமைக்கோடு கீழ்)' : 'Under ₹72,000 (BPL)'}</option>
                  <option value={100000}>{isTa ? '₹72,000 முதல் ₹1,20,000 வரை' : '₹72,000 - ₹1,20,000'}</option>
                  <option value={200000}>{isTa ? '₹1,20,000 முதல் ₹2,50,000 வரை' : '₹1,20,000 - ₹2,50,000'}</option>
                  <option value={400000}>{isTa ? '₹2,50,000-க்கு மேல்' : 'Above ₹2,50,000'}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'சமூகப் பிரிவு' : 'Community Category'}
                </label>
                <select
                  value={formData.caste_category || 'BC'}
                  onChange={(e) => setFormData({ ...formData, caste_category: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                >
                  <option value="BC">BC ({isTa ? 'பிற்படுத்தப்பட்டோர்' : 'Backward Class'})</option>
                  <option value="MBC">MBC ({isTa ? 'மிகவும் பிற்படுத்தப்பட்டோர்' : 'Most Backward Class'})</option>
                  <option value="DNC">DNC ({isTa ? 'சீர்மரபினர்' : 'De-notified Community'})</option>
                  <option value="SC">SC ({isTa ? 'ஆதிதிராவிடர்' : 'Scheduled Caste'})</option>
                  <option value="ST">ST ({isTa ? 'பழங்குடியினர்' : 'Scheduled Tribe'})</option>
                  <option value="Minority">{isTa ? 'சிறுபான்மையினர்' : 'Minority'}</option>
                  <option value="OC">OC / General ({isTa ? 'பொதுப் பிரிவு' : 'General'})</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'திருமண நிலை' : 'Marital Status'}
                </label>
                <select
                  value={formData.marital_status || 'Single'}
                  onChange={(e) => setFormData({ ...formData, marital_status: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                >
                  <option value="Single">{isTa ? 'திருமணமாகாதவர் (Single / Unmarried)' : 'Single / Unmarried'}</option>
                  <option value="Married">{isTa ? 'திருமணமானவர் (Married)' : 'Married'}</option>
                  <option value="Widow">{isTa ? 'விதவை / கைம்பெண் (Widow)' : 'Widow'}</option>
                  <option value="Deserted">{isTa ? 'கணவனால் கைவிடப்பட்டவர் (Deserted Wife)' : 'Deserted Wife'}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'மாற்றுத்திறனாளி' : 'Differently Abled (PwD)'}
                </label>
                <select
                  value={formData.disability ? 'yes' : 'no'}
                  onChange={(e) => setFormData({ ...formData, disability: e.target.value === 'yes' })}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white transition-all outline-none"
                >
                  <option value="no">{isTa ? 'இல்லை (No)' : 'No'}</option>
                  <option value="yes">{isTa ? 'ஆம் (Yes - 40%+ மாற்றுத்திறன்)' : 'Yes (Disability Certificate Holder)'}</option>
                </select>
              </div>
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Section 4: Realistic Human Voice Preference */}
          <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-100">
            <h2 className="text-xs font-bold text-[#1B5E20] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Volume2 size={16} />
              {isTa ? 'இயற்கையான மனிதக் குரல் தேர்வு (Human Neural Voice)' : 'Assistant Voice Persona'}
            </h2>
            <p className="text-xs text-gray-600 mb-3">
              {isTa 
                ? 'ரோபோடிக் குரல் அல்லாமல், தெளிவான மனிதக் குரலில் அரசு நண்பன் பதில்களைக் கேட்கலாம்.' 
                : 'High-clarity, empathetic neural human voice readout without robotic monotone.'}
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, voice_gender: 'female' })}
                className={`p-3 rounded-xl border text-left transition-all text-sm font-semibold flex items-center justify-between ${
                  formData.voice_gender === 'female'
                    ? 'border-[#1B5E20] bg-white text-[#1B5E20] shadow-sm ring-2 ring-[#1B5E20]/20'
                    : 'border-gray-200 bg-white/60 text-gray-700 hover:bg-white'
                }`}
              >
                <span>👩 {isTa ? 'பல்லவி (பெண் குரல்)' : 'Pallavi (Female)'}</span>
                {formData.voice_gender === 'female' && <span className="w-2.5 h-2.5 rounded-full bg-[#1B5E20]" />}
              </button>

              <button
                type="button"
                onClick={() => setFormData({ ...formData, voice_gender: 'male' })}
                className={`p-3 rounded-xl border text-left transition-all text-sm font-semibold flex items-center justify-between ${
                  formData.voice_gender === 'male'
                    ? 'border-[#1B5E20] bg-white text-[#1B5E20] shadow-sm ring-2 ring-[#1B5E20]/20'
                    : 'border-gray-200 bg-white/60 text-gray-700 hover:bg-white'
                }`}
              >
                <span>👨 {isTa ? 'வள்ளுவர் (ஆண் குரல்)' : 'Valluvar (Male)'}</span>
                {formData.voice_gender === 'male' && <span className="w-2.5 h-2.5 rounded-full bg-[#1B5E20]" />}
              </button>
            </div>
          </div>

          {/* Privacy Note */}
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <ShieldCheck size={16} className="text-[#1B5E20] shrink-0" />
            <span>
              {isTa 
                ? 'உங்கள் தகவல்கள் உங்கள் பிரவுசரில் மட்டுமே சேமிக்கப்பட்டு பாதுகாக்கப்படுகிறது.' 
                : 'Your profile details stay private and are used solely to match welfare schemes.'}
            </span>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-4 bg-[#1B5E20] text-white font-bold rounded-2xl text-base hover:bg-[#144718] transition-transform hover:scale-[1.01] active:scale-[0.99] shadow-lg flex items-center justify-center gap-2"
          >
            <span>{isTa ? 'விவரங்களைச் சேமித்து திட்டங்களைக் காண்க' : 'Save Profile & Discover Schemes'}</span>
            <ArrowRight size={18} />
          </button>
        </form>

      </div>
    </div>
  );
};
