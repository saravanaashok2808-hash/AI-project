import React, { useState } from 'react';
import { ExternalLink, ChevronDown, ChevronUp, FileText, CheckCircle, AlertTriangle, XCircle, HelpCircle } from 'lucide-react';
import type { Scheme, EligibilityStatus } from '../types';

interface SchemeCardProps {
  scheme: Scheme;
  eligibilityStatus?: EligibilityStatus;
  eligibilityReason?: string;
  language: 'ta' | 'en';
}

const getEligibilityConfig = (status?: EligibilityStatus) => {
  switch (status) {
    case 'ELIGIBLE':
      return { color: 'bg-green-100 text-green-800 border-green-200', icon: <CheckCircle size={16} />, labelEn: 'Eligible', labelTa: 'தகுதியானவர்' };
    case 'POTENTIALLY_ELIGIBLE':
      return { color: 'bg-yellow-100 text-yellow-800 border-yellow-200', icon: <AlertTriangle size={16} />, labelEn: 'Potentially Eligible', labelTa: 'தகுதி பெற வாய்ப்புள்ளது' };
    case 'NOT_APPEARING_ELIGIBLE':
      return { color: 'bg-red-100 text-red-800 border-red-200', icon: <XCircle size={16} />, labelEn: 'Not Eligible', labelTa: 'தகுதியற்றவர்' };
    case 'INSUFFICIENT':
      return { color: 'bg-gray-100 text-gray-800 border-gray-200', icon: <HelpCircle size={16} />, labelEn: 'More Info Needed', labelTa: 'கூடுதல் தகவல் தேவை' };
    default:
      return null;
  }
};

export const SchemeCard: React.FC<SchemeCardProps> = ({ scheme, eligibilityStatus, eligibilityReason, language }) => {
  const [expandedSection, setExpandedSection] = useState<'docs' | 'steps' | null>(null);
  
  const isTa = language === 'ta';
  const name = isTa ? scheme.name_ta : scheme.name_en;
  const benefits = isTa ? scheme.benefits_ta : scheme.benefits_en;
  const documents = isTa ? scheme.documents_ta : scheme.documents_en;
  const steps = isTa ? scheme.application_steps_ta : scheme.application_steps_en;
  
  const eligConfig = getEligibilityConfig(eligibilityStatus);

  const toggleSection = (section: 'docs' | 'steps') => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden mb-4">
      <div className="p-5 border-b border-gray-100">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-[#1B5E20]">{name}</h3>
          {eligConfig && (
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${eligConfig.color}`}>
              {eligConfig.icon}
              {isTa ? eligConfig.labelTa : eligConfig.labelEn}
            </span>
          )}
        </div>
        
        <div className="text-xs font-medium text-gray-500 mb-3 bg-gray-100 inline-block px-2 py-1 rounded">
          {scheme.department}
        </div>
        
        {eligibilityReason && (
          <div className="mt-2 text-sm p-3 bg-gray-50 rounded-lg border border-gray-100 text-gray-700">
            {eligibilityReason}
          </div>
        )}

        <div className="mt-4">
          <h4 className="text-sm font-semibold text-gray-700 mb-2">{isTa ? 'பயன்கள்' : 'Benefits'}</h4>
          <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
            {benefits.map((benefit, idx) => (
              <li key={idx}>{benefit}</li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="bg-gray-50 flex flex-col sm:flex-row border-b border-gray-100 divide-y sm:divide-y-0 sm:divide-x divide-gray-200">
        <button 
          onClick={() => toggleSection('docs')}
          className="flex-1 px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 flex items-center justify-between transition-colors"
        >
          <span className="flex items-center gap-2">
            <FileText size={16} className="text-[#1B5E20]" />
            {isTa ? 'தேவையான ஆவணங்கள்' : 'Required Documents'}
          </span>
          {expandedSection === 'docs' ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
        
        <button 
          onClick={() => toggleSection('steps')}
          className="flex-1 px-4 py-3 text-sm font-medium text-gray-700 hover:bg-gray-100 flex items-center justify-between transition-colors"
        >
          <span className="flex items-center gap-2">
            <CheckCircle size={16} className="text-[#1B5E20]" />
            {isTa ? 'விண்ணப்பிக்கும் முறை' : 'How to Apply'}
          </span>
          {expandedSection === 'steps' ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
      </div>

      {expandedSection === 'docs' && (
        <div className="p-4 bg-white text-sm text-gray-600 border-b border-gray-100">
          <ul className="list-disc pl-5 space-y-1">
            {documents.map((doc, idx) => <li key={idx}>{doc}</li>)}
          </ul>
        </div>
      )}

      {expandedSection === 'steps' && (
        <div className="p-4 bg-white text-sm text-gray-600 border-b border-gray-100">
          <ol className="list-decimal pl-5 space-y-2">
            {steps.map((step, idx) => <li key={idx}>{step}</li>)}
          </ol>
        </div>
      )}

      <div className="p-4 bg-white flex justify-between items-center">
        <div className="text-xs text-gray-400">
          {isTa ? 'கடைசியாக சரிபார்க்கப்பட்டது:' : 'Last verified:'} {new Date(scheme.last_verified_date).toLocaleDateString()}
        </div>
        <a 
          href={scheme.official_link} 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-sm font-medium text-[#1B5E20] hover:text-[#144718] hover:underline"
        >
          {isTa ? 'அதிகாரப்பூர்வ தளம்' : 'Official Site'}
          <ExternalLink size={14} />
        </a>
      </div>
    </div>
  );
};
