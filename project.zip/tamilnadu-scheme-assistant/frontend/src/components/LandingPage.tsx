import React from 'react';

interface LandingPageProps {
  onSignIn: (language: 'ta' | 'en') => void;
  onSignUp: (language: 'ta' | 'en') => void;
  onQuickStart: (language: 'ta' | 'en') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onSignIn, onSignUp, onQuickStart }) => {
  const [lang, setLang] = React.useState<'ta' | 'en'>('ta');
  const isTa = lang === 'ta';

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D3B13] via-[#1B5E20] to-[#0A290E] flex flex-col items-center justify-center p-4 sm:p-6 text-center">
      <div className="max-w-xl w-full bg-white rounded-3xl shadow-2xl p-6 sm:p-10 border border-emerald-100 my-6">
        
        {/* Language selector in top right */}
        <div className="flex justify-end mb-2">
          <button
            onClick={() => setLang(isTa ? 'en' : 'ta')}
            className="text-xs bg-emerald-50 text-[#1B5E20] border border-emerald-200 px-3 py-1 rounded-full font-semibold hover:bg-emerald-100 transition-colors"
          >
            {isTa ? '🌐 English' : '🇮🇳 தமிழ்'}
          </button>
        </div>

        <div className="w-20 h-20 bg-[#FFD700] rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg">
          <img src="/vite.svg" alt="Logo" className="w-10 h-10" />
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1B5E20] mb-1.5 leading-tight">
          {isTa ? 'தமிழ்நாடு அரசுத் திட்ட வழிகாட்டி' : 'TN Government Scheme Assistant'}
        </h1>
        <h2 className="text-sm sm:text-base font-semibold text-gray-700 mb-4">
          {isTa ? 'அரசு நண்பன் - குடிமக்கள் நலத்திட்ட சேவை' : 'Arasu Nanban - Multilingual Voice Guide'}
        </h2>

        <p className="text-gray-600 text-xs sm:text-sm mb-6 max-w-md mx-auto leading-relaxed">
          {isTa 
            ? 'உங்கள் வயது, படிப்பு மற்றும் தொழில் விவரங்களை உள்ளிட்டு, உங்களுக்குத் தகுதியான 59+ தமிழ்நாடு அரசு நலத்திட்டங்களை உடனே கண்டறியுங்கள். குரல் மூலமாகவும் உரையாடலாம்.' 
            : 'Enter your profile details to instantly discover verified welfare schemes matched to your eligibility. Complete with natural human voice interaction.'}
        </p>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={() => onSignUp(lang)}
            className="w-full py-3.5 bg-[#1B5E20] text-white font-bold rounded-xl text-sm hover:bg-[#144718] transition-transform hover:scale-[1.01] active:scale-[0.99] shadow-lg flex items-center justify-center gap-2"
          >
            <span>{isTa ? 'புதிய பதிவு & சுயவிவரம் (Sign Up / Register)' : 'Sign Up & Setup Profile'}</span>
          </button>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => onSignIn(lang)}
              className="py-3 bg-white border-2 border-[#1B5E20] text-[#1B5E20] font-bold rounded-xl text-xs sm:text-sm hover:bg-emerald-50 transition-colors shadow-sm"
            >
              {isTa ? 'உள்நுழைக (Sign In)' : 'Sign In'}
            </button>

            <button
              onClick={() => onQuickStart(lang)}
              className="py-3 bg-gray-50 border border-gray-300 text-gray-700 font-bold rounded-xl text-xs sm:text-sm hover:bg-gray-100 transition-colors"
            >
              {isTa ? 'விருந்தினர் தொடக்கம் (Guest)' : 'Quick Guest Start'}
            </button>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-gray-100 text-[11px] text-gray-400">
          {isTa ? 'தமிழ்நாடு அரசு நலத்திட்ட வழிகாட்டி • 100% இலவசம் & பாதுகாப்பானது' : 'Tamil Nadu Welfare Scheme Assistant • ₹0 Cost Open Source'}
        </div>
      </div>
    </div>
  );
};
