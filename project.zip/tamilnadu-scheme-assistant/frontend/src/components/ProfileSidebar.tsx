import React from 'react';
import type { UserProfile } from '../types';
import { User, X, Shield } from 'lucide-react';

interface ProfileSidebarProps {
  profile: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onClearSession: () => void;
  language: 'ta' | 'en';
}

export const ProfileSidebar: React.FC<ProfileSidebarProps> = ({ profile, isOpen, onClose, onClearSession, language }) => {
  const isTa = language === 'ta';

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/50 z-40 transition-opacity" onClick={onClose} />
      <div className="fixed inset-y-0 right-0 max-w-xs w-full bg-white shadow-xl z-50 transform transition-transform overflow-y-auto flex flex-col">
        <div className="p-4 bg-[#1B5E20] text-white flex justify-between items-center">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <User size={20} />
            {isTa ? 'உங்கள் விவரங்கள்' : 'Your Profile'}
          </h2>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="p-4 flex-1">
          <p className="text-sm text-gray-500 mb-6">
            {isTa 
              ? 'உரையாடலில் இருந்து எடுக்கப்பட்ட தகவல்கள். தகுந்த திட்டங்களை பரிந்துரைக்க இவை பயன்படும்.' 
              : 'Information extracted from our conversation to help find relevant schemes.'}
          </p>

          <div className="space-y-4">
            <ProfileField label={isTa ? 'வயது' : 'Age'} value={profile.age?.toString()} />
            <ProfileField label={isTa ? 'பாலினம்' : 'Gender'} value={profile.gender} />
            <ProfileField label={isTa ? 'மாவட்டம்' : 'District'} value={profile.district} />
            <ProfileField label={isTa ? 'பணி' : 'Occupation'} value={profile.occupation} />
            <ProfileField label={isTa ? 'வருமானம்' : 'Income'} value={profile.income ? `₹${profile.income}` : undefined} />
            <ProfileField label={isTa ? 'திருமண நிலை' : 'Marital Status'} value={profile.marital_status} />
            <ProfileField label={isTa ? 'சாதி வகை' : 'Category'} value={profile.caste_category} />
            <ProfileField label={isTa ? 'மாற்றுத்திறனாளி' : 'Disability'} value={profile.disability !== undefined ? (profile.disability ? (isTa ? 'ஆம்' : 'Yes') : (isTa ? 'இல்லை' : 'No')) : undefined} />
          </div>
        </div>

        <div className="p-4 border-t border-gray-100 bg-gray-50">
          <div className="flex items-start gap-2 mb-4 text-xs text-gray-500">
            <Shield size={14} className="mt-0.5 flex-shrink-0" />
            <p>{isTa 
              ? 'உங்கள் தரவுகள் பாதுகாப்பாக உள்ளன, மூடும்போது அழிக்கப்படும்.' 
              : 'Your data is processed securely and cleared when session ends.'}
            </p>
          </div>
          <button
            onClick={onClearSession}
            className="w-full py-2 px-4 bg-white border border-red-200 text-red-600 rounded-lg text-sm font-medium hover:bg-red-50 transition-colors"
          >
            {isTa ? 'அனைத்து தரவையும் அழி' : 'Clear All Data'}
          </button>
        </div>
      </div>
    </>
  );
};

const ProfileField = ({ label, value }: { label: string; value?: string }) => {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-500 mb-1">{label}</label>
      <div className="text-sm text-gray-900 bg-gray-50 border border-gray-200 rounded px-3 py-2 min-h-[38px] flex items-center">
        {value || <span className="text-gray-400 italic">Not provided</span>}
      </div>
    </div>
  );
};
