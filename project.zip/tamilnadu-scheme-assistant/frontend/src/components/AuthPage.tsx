import React, { useState } from 'react';
import type { UserProfile } from '../types';
import { User, LogIn, UserPlus, ArrowRight, Sparkles } from 'lucide-react';
import { TN_DISTRICTS } from './ProfileOnboarding';

interface AuthPageProps {
  language: 'ta' | 'en';
  onLogin: (profile: UserProfile) => void;
  onSignUp: (initialProfile: UserProfile) => void;
  onGuest: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ language, onLogin, onSignUp, onGuest }) => {
  const isTa = language === 'ta';
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');

  // Sign in state
  const [loginIdentifier, setLoginIdentifier] = useState('');

  // Sign up state
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [district, setDistrict] = useState('Chennai');
  const [age, setAge] = useState<number>(24);
  const [gender, setGender] = useState('Female');

  // Existing local accounts
  const savedCitizens: UserProfile[] = (() => {
    try {
      const data = localStorage.getItem('tn_saved_citizens');
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  })();

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginIdentifier.trim()) return;

    // Check if citizen already exists
    const existing = savedCitizens.find(
      c => c.name?.toLowerCase() === loginIdentifier.toLowerCase() || c.phone === loginIdentifier
    );

    if (existing) {
      onLogin(existing);
    } else {
      // Create new profile with this identifier
      onLogin({
        name: loginIdentifier,
        district: 'Chennai',
        age: 25,
        gender: 'Female',
        occupation: 'Student'
      });
    }
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newCitizen: UserProfile = {
      name,
      phone,
      district,
      age,
      gender,
    };

    onSignUp(newCitizen);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0D3B13] via-[#1B5E20] to-[#0A290E] p-4 sm:p-6 flex items-center justify-center">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-emerald-100 my-8">
        
        {/* Header */}
        <div className="bg-[#1B5E20] text-white p-6 sm:p-8 text-center relative">
          <div className="w-16 h-16 bg-[#FFD700] rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg">
            <img src="/vite.svg" alt="Emblem" className="w-8 h-8" />
          </div>
          <h1 className="text-xl sm:text-2xl font-bold">
            {isTa ? 'தமிழ்நாடு அரசுத் திட்ட வழிகாட்டி' : 'TN Scheme Assistant'}
          </h1>
          <p className="text-white/80 text-xs mt-1">
            {isTa ? 'அரசு நண்பன் - குடிமக்கள் உள்நுழைவு & சுயவிவர போர்டல்' : 'Citizen Login & Welfare Scheme Portal'}
          </p>

          {/* Mode Switcher Tabs */}
          <div className="flex bg-black/20 p-1 rounded-xl mt-6">
            <button
              onClick={() => setMode('signin')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                mode === 'signin' ? 'bg-white text-[#1B5E20] shadow-sm' : 'text-white/80 hover:text-white'
              }`}
            >
              <LogIn size={14} />
              {isTa ? 'உள்நுழைக' : 'Sign In'}
            </button>
            <button
              onClick={() => setMode('signup')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                mode === 'signup' ? 'bg-white text-[#1B5E20] shadow-sm' : 'text-white/80 hover:text-white'
              }`}
            >
              <UserPlus size={14} />
              {isTa ? 'புதிய பதிவு' : 'Sign Up'}
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8">
          {mode === 'signin' ? (
            <form onSubmit={handleSignIn} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'பெயர் அல்லது மொபைல் எண்' : 'Name or Mobile Number'}
                </label>
                <div className="relative">
                  <User size={18} className="absolute left-3.5 top-3 text-gray-400" />
                  <input
                    type="text"
                    required
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    placeholder={isTa ? 'எ.கா: கார்த்திக் அல்லது 9876543210' : 'e.g. Priya or 9876543210'}
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white outline-none"
                  />
                </div>
              </div>

              {savedCitizens.length > 0 && (
                <div className="pt-2">
                  <p className="text-xs font-semibold text-gray-500 mb-2">
                    {isTa ? 'முன்பு உள்நுழைந்த பயனர்கள்:' : 'Saved Citizens on this device:'}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {savedCitizens.map((c, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => onLogin(c)}
                        className="px-3 py-1.5 bg-emerald-50 text-[#1B5E20] border border-emerald-200 rounded-lg text-xs font-medium hover:bg-emerald-100 flex items-center gap-1"
                      >
                        <User size={12} />
                        <span>{c.name}</span>
                        {c.age && <span className="text-[10px] text-gray-500">({c.age}y)</span>}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <button
                type="submit"
                className="w-full mt-4 py-3 bg-[#1B5E20] text-white font-bold rounded-xl text-sm hover:bg-[#144718] transition-colors shadow-md flex items-center justify-center gap-2"
              >
                <span>{isTa ? 'உள்நுழையவும்' : 'Sign In to Assistant'}</span>
                <ArrowRight size={16} />
              </button>
            </form>
          ) : (
            <form onSubmit={handleSignUp} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'உங்கள் பெயர்' : 'Full Name'} *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={isTa ? 'எ.கா: கார்த்திகேயன்' : 'e.g. Karthikeyan'}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    {isTa ? 'வயது' : 'Age'} *
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    required
                    value={age}
                    onChange={(e) => setAge(parseInt(e.target.value) || 0)}
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    {isTa ? 'பாலினம்' : 'Gender'}
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white outline-none"
                  >
                    <option value="Female">{isTa ? 'பெண்' : 'Female'}</option>
                    <option value="Male">{isTa ? 'ஆண்' : 'Male'}</option>
                    <option value="Transgender">{isTa ? 'திருநங்கை' : 'Transgender'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'மாவட்டம்' : 'District'}
                </label>
                <select
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white outline-none"
                >
                  {TN_DISTRICTS.map((dist) => (
                    <option key={dist} value={dist}>{dist}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {isTa ? 'மொபைல் எண் (விருப்பத்தேர்வு)' : 'Mobile Number (Optional)'}
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="9876543210"
                  className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-[#1B5E20] focus:bg-white outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full mt-4 py-3 bg-[#1B5E20] text-white font-bold rounded-xl text-sm hover:bg-[#144718] transition-colors shadow-md flex items-center justify-center gap-2"
              >
                <span>{isTa ? 'பதிவு செய்து சுயவிவரத்தை நிரப்பவும்' : 'Sign Up & Setup Profile'}</span>
                <ArrowRight size={16} />
              </button>
            </form>
          )}

          {/* Quick guest option */}
          <div className="mt-6 pt-4 border-t border-gray-200 text-center">
            <button
              onClick={onGuest}
              className="text-xs text-gray-600 hover:text-[#1B5E20] font-medium flex items-center justify-center gap-1 mx-auto"
            >
              <Sparkles size={13} className="text-[#1B5E20]" />
              <span>{isTa ? 'விருந்தினராக தொடரவும் (Quick Guest Onboarding)' : 'Continue as Guest Citizen'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
